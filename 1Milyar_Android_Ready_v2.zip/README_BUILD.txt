1Milyar.com Android APK project v2

This is a complete Android WebView project based on the supplied Multi-Device v1 HTML.
GitHub Actions workflow is included.

Build on GitHub:
1. Upload the entire project preserving folders.
2. Actions -> Build 1Milyar APK -> Run workflow.
3. Download artifact: 1Milyar-com-APK.

Cloud sync is not enabled yet because the supplied HTML has empty Supabase URL/anonKey.
