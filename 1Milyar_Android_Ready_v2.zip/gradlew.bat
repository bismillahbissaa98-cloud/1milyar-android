@echo off
setlocal
set GRADLE_VERSION=8.10.2
set DIST=%USERPROFILE%\.gradle\gradle-%GRADLE_VERSION%-bin
if not exist "%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat" (
  mkdir "%DIST%" 2>nul
  powershell -NoProfile -Command "(New-Object Net.WebClient).DownloadFile('https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip', '%USERPROFILE%\.gradle\gradle-%GRADLE_VERSION%-bin.zip')"
  powershell -NoProfile -Command "Expand-Archive -Force '%USERPROFILE%\.gradle\gradle-%GRADLE_VERSION%-bin.zip' '%DIST%'"
)
call "%DIST%\gradle-%GRADLE_VERSION%\bin\gradle.bat" %*
